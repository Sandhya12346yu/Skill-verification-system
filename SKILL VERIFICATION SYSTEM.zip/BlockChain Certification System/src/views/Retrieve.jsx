import React from "react";
import Nav from "../components/Nav"; 

const Retrieve = () => {
    return (
        <div>
            <Nav cmp={"retrieve"} />
        </div>
    );
};

export default Retrieve;
