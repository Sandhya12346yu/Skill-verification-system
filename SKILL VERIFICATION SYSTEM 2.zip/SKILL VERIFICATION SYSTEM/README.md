# BLOCK CHAIN MANAGEMENT PROJECT NAME:-SKILL VERIFICATION SYSTEM

this is the files as you asked me to  add them to a github 

Competency checks, skill verification, and increasing trust in organizational skill and competency management can all benefit from a blockchain-based skill verification system. With Blockchain, a worker's credentials can be documented on a shared ledger that has been checked and approved by past supervisors and employers. Thus with a skill chain based on the blockchain for an employee, we can be completely certain of the skills, experience, learning objective progress and their competency level along with a transparency of who have endorsed the employees on these talents. In addition, this will assist the company in maximizing the use of trustworthy personnel to meet its objectives.



### Use cases

First, it's a tool that HR may utilize to streamline the hiring process.
The employee can use this as leverage to get hired by his ideal employer.
Third, it can be used to verify someone's skills.
Fourth, it can be used to have a conversation with a company or a group of people within that company.


## Features

Employees and human resources personnel can use the website's _**search feature**_ to look for candidates who meet specific job criteria.
- A _**Notification**_ System that sends a reminder to the worker ahead of time of their scheduled meeting.
- Notification For Certifications and skill endorsements.
Employee profiles that include _**Charts and graphs**_ that display endorsement ratings, certification timestamps, etc.
- **Barcode scanner**_ for scanning the barcode created from the employee's and the company's public key hash.
- A built-in chat function for communicating with HR staff.Employees can request for an endorsement for a skill,certification and experience and HR can connect with employee for an interview.
Conversations are encrypted from "end to end" with public-private key technology.
There is no need to register or log in again because your MetaMask account will handle your login for you.


### Brief Flow Diagram
![image](https://user-images.githubusercontent.com/64866670/139016957-94d8ff46-c6c8-4c36-97bb-7e75473e3ae3.png)

---

## Roles

1. **No Role** - Any user with an ethereum wallet can share their details and cha with the site's administrators.
    - Any job or position in any company is open to him.


To add a new user to the blockchain, a **Admin** must first register them.
    Maintains strict command over blockchain ambiguity.
    Reacts to user requests for new roles.
    User retention and growth optimization.
    Users' permissions can be changed or removed.


Thirdly, **Employees** — This smart contract is intended for Employees and will be used to store Employee-Related Information.
    Name of Employee, Total Endorsement Rating, and Endorsement Ratings for Each Skill on a Scale from 1 to 10.
    Verified certifications will be one kind, and non-verified certifications will be another. When the certification is approved by the issuing body on the blockchain, it is considered validated.
    The Work Experience section will be divided into two types: verified and not verified, including areas for information such as employer, position, and duties. If the institution confirms it on the blockchain, it is credible.
    Rankings on Online Competition Platforms Such as HackerEarth, CodeChef, CodeForces, etc.The exact ratings will be presented on the website without the need to click on a ton of links for verification because they will have already been checked via an API call to the server of the specified platforms.
    The employee's transcript is compared to the information in the blockchain, and if there are discrepancies, the institution's API domain is used to double-check the employee's findings.



Fourth, **Organization Endorser** - The organizations endorsing this smart contract. Employers can use this to confirm an applicant's claimed qualifications, employment history, education, and certifications.The smart contracts include: - The name of the company; - A directory of the people now employed by that company; - A list of those people who are authorized to vouch for the qualifications, work history, and education of other employees. Current employees only have that authority; former ones do not.
    Human resources staff, the talent acquisition team, and all current employees are all listed.
    - It will provide a function for changing an employee's title.
    Certificates of achievement can be awarded to staff members and shown in their profiles.
    Candidates can be found on the blockchain and invited for an interview based on keywords in the job posting.
.

## Thumbnails
![1](https://user-images.githubusercontent.com/64866670/139017444-553f4e7a-b3bd-4e45-b4a9-5d5d6c9a4ff3.png)
![2](https://user-images.githubusercontent.com/64866670/139017530-f4ce07a3-2888-48e4-a7b1-86c5adfbb69d.png)
![3](https://user-images.githubusercontent.com/64866670/139017569-2018caf2-3d14-47c6-bf52-74c066ec57c2.png)
![4](https://user-images.githubusercontent.com/64866670/139017586-0890110f-e538-4627-9190-7eda686afa37.png)
![5](https://user-images.githubusercontent.com/64866670/139017605-a8468e44-6882-4ac7-9466-a2d80c6ab0bd.png)
![6](https://user-images.githubusercontent.com/64866670/139017624-0859fecb-49d3-4f65-99cd-389ba30dda96.png)
![7](https://user-images.githubusercontent.com/64866670/139017487-2c2c31e9-f392-4eb9-a64e-5d773958dc1c.png)



